import streamlit as st
import pickle

model = pickle.load(open('logistic_model.pkl', 'rb'))

st.title("Diabetes Prediction App")

Pregnancies = st.number_input("Pregnancies")
Glucose = st.number_input("Glucose")
BloodPressure = st.number_input("Blood Pressure")
SkinThickness = st.number_input("Skin Thickness")
Insulin = st.number_input("Insulin")
BMI = st.number_input("BMI")
DiabetesPedigreeFunction = st.number_input("Diabetes Pedigree Function")
Age = st.number_input("Age")

if st.button("Predict"):

    data = [[
        Pregnancies,
        Glucose,
        BloodPressure,
        SkinThickness,
        Insulin,
        BMI,
        DiabetesPedigreeFunction,
        Age
    ]]

    prediction = model.predict(data)

    if prediction[0] == 1:
        st.success("Diabetic")
    else:
        st.success("Non-Diabetic")